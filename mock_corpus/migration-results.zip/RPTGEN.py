from decimal import Decimal, ROUND_HALF_UP

def main():
    order_number = 'ORD-2026-000123'
    customer_id = 'CUST000042'
    line_count = 8

    order_lines = []
    for i in range(1, line_count + 1):
        qty = i * 17 + 10
        unit_price = (Decimal(i) * Decimal('23.45') + Decimal('5.00')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        line_total = (Decimal(qty) * unit_price).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        if i % 3 == 0:
            status = 'F'
        elif i % 2 == 0:
            status = 'P'
        else:
            status = 'O'
        order_lines.append({
            'line_number': i,
            'qty_ordered': qty,
            'unit_price': unit_price,
            'line_total': line_total,
            'line_status': status
        })

    grand_total_qty = sum(line['qty_ordered'] for line in order_lines)
    grand_total_amt = sum(line['line_total'] for line in order_lines)

    open_count = sum(1 for line in order_lines if line['line_status'] == 'O')
    filled_count = sum(1 for line in order_lines if line['line_status'] == 'F')
    partial_count = sum(1 for line in order_lines if line['line_status'] == 'P')

    high_value_threshold = Decimal('1000.00')
    high_value_count = sum(1 for line in order_lines if line['line_total'] > high_value_threshold)

    dash_line = '-' * 80

    print(dash_line)
    print('ORDER LINE SUMMARY REPORT')
    print(f'ORDER NUMBER: {order_number}')
    print(f'CUSTOMER ID:  {customer_id}')
    print(dash_line)

    print('CATEGORY BREAKDOWN NOT YET POPULATED')

    print(dash_line)
    print(f'TOTAL LINES:      {line_count}')
    print(f'OPEN LINES:       {open_count}')
    print(f'FILLED LINES:     {filled_count}')
    print(f'PARTIAL LINES:    {partial_count}')
    print(f'HIGH VALUE LINES: {high_value_count}')
    print(f'GRAND TOTAL QTY:  {grand_total_qty}')
    print(f'GRAND TOTAL AMT:  {grand_total_amt:.2f}')

    if line_count > 0:
        average_line_value = (grand_total_amt / line_count).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        print(f'AVERAGE LINE VALUE: {average_line_value:.2f}')

    print(dash_line)

if __name__ == '__main__':
    main()
