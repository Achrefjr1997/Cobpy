from decimal import Decimal
from shared_models import CustmastModel, OrdlineModel, InvmastModel
from custval import custval
from invchk import invchk
from pricecalc import pricecalc
from taxcalc import taxcalc
from invupdate import invupdate
from glpost import glpost

MSG_CUSTOMER_NOT_FOUND = 'CUSTOMER NOT FOUND'
MSG_CUSTOMER_FROZEN = 'CUSTOMER ACCOUNT FROZEN'
MSG_CREDIT_EXCEEDED = 'CREDIT LIMIT EXCEEDED'
MSG_ITEM_NOT_FOUND = 'ITEM NOT FOUND IN INVENTORY'
MSG_INSUFFICIENT_STOCK = 'INSUFFICIENT STOCK AVAILABLE'
MSG_ORDER_APPROVED = 'ORDER APPROVED FOR SHIPMENT'
MSG_ORDER_BACKORDERED = 'ORDER PLACED ON BACKORDER'
MSG_TAX_CALC_ERROR = 'TAX CALCULATION ERROR'
MSG_GL_POST_SUCCESS = 'GL POSTING COMPLETED'


def main():
    # Initialize customer
    customer = CustmastModel(
        cm_customer_id='CUST000042',
        cm_first_name='JANE',
        cm_last_name='DOE',
        cm_street='',
        cm_city='',
        cm_state='',
        cm_zip='',
        cm_country='',
        cm_phone='',
        cm_email='',
        cm_credit_limit=Decimal('15000.00'),
        cm_balance_due=Decimal('2500.00'),
        cm_ytd_purchases=Decimal('0.00'),
        cm_discount_pct=Decimal('5.00'),
        cm_payment_terms=0,
        cm_status_code='A',
        cm_risk_category='L',
        cm_last_order_date=0,
        cm_customer_since=0,
        cm_sales_rep_id='',
        cm_region_code=''
    )

    # Initialize inventory master (single item for all lines)
    inventory = InvmastModel(
        im_item_id='ITEM000001',
        im_item_desc='',
        im_category_code='',
        im_unit_cost=Decimal('0.00'),
        im_unit_price=Decimal('199.99'),
        im_reorder_point=0,
        im_reorder_qty=0,
        im_warehouse_count=2,
        im_warehouse_table=[
            type('Warehouse', (), {
                'wh_location_code': 'WH-EAST',
                'wh_qty_on_hand': 0,
                'wh_qty_allocated': 0,
                'wh_qty_available': 500,
                'wh_bin_number': ''
            })(),
            type('Warehouse', (), {
                'wh_location_code': 'WH-WEST',
                'wh_qty_on_hand': 0,
                'wh_qty_allocated': 0,
                'wh_qty_available': 300,
                'wh_bin_number': ''
            })()
        ],
        im_status_code='A',
        im_lead_time_days=0,
        im_vendor_id='',
        im_last_receipt_date=0,
        im_last_count_date=0
    )

    # Order-level fields
    ws_order_number = '000001000001'
    ws_subtotal = Decimal('0.00')
    ws_tax_total = Decimal('0.00')
    ws_freight_amt = Decimal('25.00')
    ws_order_total = Decimal('0.00')
    ws_line_count = 3
    ws_ship_to_state = 'CA'
    ws_posting_date = 20260101
    ws_order_backordered_flag = False

    # Customer validation
    validation_result, result_message = custval(customer, ws_subtotal)
    if validation_result != 'V':
        print(f'ORDER REJECTED: {result_message}')
        return 8

    # Process each line
    for _ in range(ws_line_count):
        line = OrdlineModel(
            olw_item_id=inventory.im_item_id,
            olw_qty_requested=50,
            olw_qty_available=0,
            olw_unit_price=Decimal('0.00'),
            olw_extended_price=Decimal('0.00'),
            olw_result_code=''
        )

        invchk(inventory, line)

        if line.olw_result_code == 'N':
            print(MSG_ITEM_NOT_FOUND)
        else:
            extended_price, final_price, discount_amt = pricecalc(
                line.olw_qty_requested,
                line.olw_unit_price,
                customer.cm_discount_pct
            )
            ws_subtotal += final_price

            qty_allocated_total, allocation_status = invupdate(inventory, line.olw_qty_requested)
            if allocation_status == 'P':
                ws_order_backordered_flag = True
            if line.olw_result_code == 'S':
                ws_order_backordered_flag = True

    # Tax calculation
    tax_amount, tax_rate, tax_return_code = taxcalc(ws_ship_to_state, ws_subtotal)
    ws_tax_total = tax_amount

    # Order total
    ws_order_total = ws_subtotal + ws_tax_total + ws_freight_amt

    # GL posting
    gl_entries = [
        {
            'gl_account_number': '',
            'gl_account_desc': '',
            'gl_entry_type': '',
            'gl_amount': Decimal('0.00'),
            'gl_posting_date': 0,
            'gl_source_ref': '',
            'gl_posted_flag': ''
        }
        for _ in range(4)
    ]
    entries_created = glpost(ws_order_number, ws_subtotal, ws_tax_total, ws_freight_amt, ws_posting_date, gl_entries)

    # Final status
    if ws_order_backordered_flag:
        print(MSG_ORDER_BACKORDERED)
    else:
        print(MSG_ORDER_APPROVED)

    print(f'ORDER TOTAL: {ws_order_total}')
    print(f'GL ENTRIES POSTED: {entries_created}')

    return 0


if __name__ == '__main__':
    main()