from decimal import Decimal, ROUND_HALF_UP

def glpost(order_number, subtotal_amount, tax_amount, freight_amount, posting_date):
    """
    Builds 4 GL entries for an order.
    Returns (gl_entries, entries_created).
    """
    # Convert amounts to Decimal with 2 decimal places, rounding as COBOL ROUNDED
    subtotal = Decimal(str(subtotal_amount)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    tax = Decimal(str(tax_amount)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    freight = Decimal(str(freight_amount)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    ar_amount = (subtotal + tax + freight).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    entries = [
        {
            'account_number': '400000',
            'account_desc': 'SALES REVENUE',
            'entry_type': 'C',
            'amount': subtotal,
            'posting_date': posting_date,
            'source_ref': order_number,
            'posted_flag': 'N'
        },
        {
            'account_number': '120000',
            'account_desc': 'ACCOUNTS RECEIVABLE',
            'entry_type': 'D',
            'amount': ar_amount,
            'posting_date': posting_date,
            'source_ref': order_number,
            'posted_flag': 'N'
        },
        {
            'account_number': '210000',
            'account_desc': 'SALES TAX PAYABLE',
            'entry_type': 'C',
            'amount': tax,
            'posting_date': posting_date,
            'source_ref': order_number,
            'posted_flag': 'N'
        },
        {
            'account_number': '410000',
            'account_desc': 'FREIGHT REVENUE',
            'entry_type': 'C',
            'amount': freight,
            'posting_date': posting_date,
            'source_ref': order_number,
            'posted_flag': 'N'
        }
    ]
    entries_created = 4
    return entries, entries_created

def main():
    # Example usage
    order_num = "ORD123456789"
    subtotal = 1000.00
    tax = 80.00
    freight = 25.00
    date = 20250315
    gl_entries, count = glpost(order_num, subtotal, tax, freight, date)
    print(f"Entries created: {count}")
    for i, entry in enumerate(gl_entries, 1):
        print(f"Entry {i}: {entry}")

if __name__ == "__main__":
    main()
