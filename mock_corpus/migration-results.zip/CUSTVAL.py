from decimal import Decimal
from shared_models import CustmastModel, MSG_CUSTOMER_NOT_FOUND, MSG_CUSTOMER_FROZEN, MSG_CREDIT_EXCEEDED

def validate_customer(customer: CustmastModel, order_amount: Decimal) -> tuple[str, str]:
    result = 'V'
    message = ''
    
    if customer.cm_status_code == 'C':
        result = 'X'
        message = MSG_CUSTOMER_NOT_FOUND
    elif customer.cm_status_code == 'F':
        result = 'F'
        message = MSG_CUSTOMER_FROZEN
    else:
        # Check credit limit
        discount_factor = Decimal('1') - (customer.cm_discount_pct / Decimal('100'))
        discounted_limit = (customer.cm_credit_limit * discount_factor).quantize(Decimal('0.01'))
        projected_balance = (customer.cm_balance_due + order_amount).quantize(Decimal('0.01'))
        if projected_balance > discounted_limit:
            result = 'C'
            message = MSG_CREDIT_EXCEEDED
    
    if result == 'V':
        # Apply risk adjustment
        if customer.cm_risk_category == 'H' and order_amount > Decimal('5000.00'):
            result = 'C'
            message = MSG_CREDIT_EXCEEDED
        elif customer.cm_risk_category == 'M' and order_amount > Decimal('25000.00'):
            result = 'C'
            message = MSG_CREDIT_EXCEEDED
        # 'L' or other: no change
    
    return result, message

def main():
    # Example usage
    customer = CustmastModel(
        cm_customer_id="CUST001",
        cm_first_name="John",
        cm_last_name="Doe",
        cm_street="123 Main St",
        cm_city="Anytown",
        cm_state="CA",
        cm_zip="12345",
        cm_country="US",
        cm_phone="555-1234",
        cm_email="john@example.com",
        cm_credit_limit=Decimal('10000.00'),
        cm_balance_due=Decimal('2000.00'),
        cm_ytd_purchases=Decimal('5000.00'),
        cm_discount_pct=Decimal('10.00'),
        cm_payment_terms=30,
        cm_status_code='A',
        cm_risk_category='M',
        cm_last_order_date=20230101,
        cm_customer_since=20200101,
        cm_sales_rep_id='SR001',
        cm_region_code='WEST'
    )
    order_amount = Decimal('15000.00')
    result, msg = validate_customer(customer, order_amount)
    print(f"Result: {result}, Message: {msg}")

if __name__ == "__main__":
    main()