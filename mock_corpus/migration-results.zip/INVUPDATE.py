from models import InvmastModel

def invupdate(inv_mast: InvmastModel, qty_to_allocate: int) -> tuple[int, str]:
    remaining = qty_to_allocate
    total_allocated = 0

    for wh in inv_mast.im_warehouse_table[:inv_mast.im_warehouse_count]:
        if remaining == 0:
            break
        if wh.wh_qty_available > 0:
            allocate = remaining if wh.wh_qty_available >= remaining else wh.wh_qty_available
            wh.wh_qty_allocated += allocate
            wh.wh_qty_available -= allocate
            remaining -= allocate
            total_allocated += allocate

    if remaining == 0:
        status = 'F'
    elif total_allocated > 0:
        status = 'P'
    else:
        status = 'N'

    if status in ('F', 'P'):
        inv_mast.im_status_code = 'A'

    return total_allocated, status

def main():
    from decimal import Decimal

    class Warehouse:
        def __init__(self, wh_location_code, wh_qty_on_hand, wh_qty_allocated, wh_qty_available, wh_bin_number):
            self.wh_location_code = wh_location_code
            self.wh_qty_on_hand = wh_qty_on_hand
            self.wh_qty_allocated = wh_qty_allocated
            self.wh_qty_available = wh_qty_available
            self.wh_bin_number = wh_bin_number

    inv = InvmastModel(
        im_item_id='ITEM001',
        im_item_desc='Test Item',
        im_category_code='E',
        im_unit_cost=Decimal('10.00'),
        im_unit_price=Decimal('20.00'),
        im_reorder_point=100,
        im_reorder_qty=200,
        im_warehouse_count=2,
        im_warehouse_table=[
            Warehouse('WH1', 50, 0, 50, 'BIN1'),
            Warehouse('WH2', 30, 0, 30, 'BIN2')
        ],
        im_status_code='D',
        im_lead_time_days=5,
        im_vendor_id='VENDOR01',
        im_last_receipt_date=20230101,
        im_last_count_date=20230101
    )
    total, status = invupdate(inv, 60)
    print(f'Allocated: {total}, Status: {status}')
    print(f'Item status: {inv.im_status_code}')
    for wh in inv.im_warehouse_table[:inv.im_warehouse_count]:
        print(f'{wh.wh_location_code}: allocated={wh.wh_qty_allocated}, available={wh.wh_qty_available}')

if __name__ == '__main__':
    main()