from decimal import Decimal, ROUND_HALF_UP

def pricecalc(qty_ordered, unit_price, customer_discount_pct):
    # Convert inputs to Decimal for precise arithmetic
    qty = Decimal(str(qty_ordered))
    unit = Decimal(str(unit_price))
    cust_disc = Decimal(str(customer_discount_pct))

    # Extended price = qty * unit, rounded to 2 decimal places
    extended_price = (qty * unit).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    # Determine volume discount percentage based on quantity tiers
    if qty >= 1000:
        volume_disc = Decimal('15.00')
    elif qty >= 500:
        volume_disc = Decimal('10.00')
    elif qty >= 100:
        volume_disc = Decimal('5.00')
    elif qty >= 25:
        volume_disc = Decimal('2.00')
    else:
        volume_disc = Decimal('0.00')

    # Combined discount, capped at 50%
    combined_disc = volume_disc + cust_disc
    if combined_disc > Decimal('50.00'):
        combined_disc = Decimal('50.00')

    # Discount factor = 1 - combined_disc/100, rounded to 4 decimal places (PIC 9V9999)
    discount_factor = (Decimal('1') - (combined_disc / Decimal('100'))).quantize(
        Decimal('0.0001'), rounding=ROUND_HALF_UP
    )

    # Final price = extended_price * discount_factor, rounded to 2 decimal places
    final_price = (extended_price * discount_factor).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    # Total discount amount = extended_price - final_price, rounded to 2 decimal places
    total_discount_amt = (extended_price - final_price).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    return extended_price, final_price, total_discount_amt


def main():
    # Entry point – no output to avoid mismatch with COBOL's silent subprogram
    pass


if __name__ == "__main__":
    main()