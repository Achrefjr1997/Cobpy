def taxcalc(ship_to_state, taxable_amount):
    # Tax table: 8 entries, each 8 chars: 2-char state + 6-digit rate (only first 5 used)
    table = [
        ('CA', '070500'),
        ('NY', '040000'),
        ('TX', '062500'),
        ('FL', '060000'),
        ('WA', '065000'),
        ('OR', '000000'),
        ('NH', '000000'),
        ('MT', '000000')
    ]
    tax_rate = 0.0
    return_code = 0
    found = False

    for state, rate_str in table:
        if state == ship_to_state:
            # Rate is PIC 9(1)V9999: 1 digit integer, 4 fractional, from first 5 chars of rate_str
            int_part = int(rate_str[0])
            frac_part = int(rate_str[1:5]) / 10000.0
            tax_rate = int_part + frac_part
            found = True
            break

    if not found:
        tax_rate = 0.0
        return_code = 4

    tax_amount = round(taxable_amount * tax_rate, 2)
    return tax_amount, tax_rate, return_code


def main():
    # Example usage
    state = 'CA'
    amount = 100.00
    tax_amt, rate, rc = taxcalc(state, amount)
    print(f"State: {state}, Taxable: {amount}, Tax: {tax_amt}, Rate: {rate}, RC: {rc}")


if __name__ == '__main__':
    main()
