from decimal import Decimal, ROUND_HALF_UP
from shared_models import InvmastModel, OrdlineModel


def invchk(inventory_master_rec: InvmastModel, order_line_work_rec: OrdlineModel) -> None:
    total_available = 0
    best_wh_qty = 0
    order_line_work_rec.olw_result_code = 'K'

    if inventory_master_rec.im_status_code == 'D':
        order_line_work_rec.olw_result_code = 'N'
        return

    for wh in inventory_master_rec.im_warehouse_table:
        total_available += wh.wh_qty_available
        if wh.wh_qty_available > best_wh_qty:
            best_wh_qty = wh.wh_qty_available

    order_line_work_rec.olw_qty_available = total_available

    if total_available < order_line_work_rec.olw_qty_requested:
        if total_available == 0:
            order_line_work_rec.olw_result_code = 'N'
        else:
            order_line_work_rec.olw_result_code = 'S'
    else:
        order_line_work_rec.olw_result_code = 'K'

    order_line_work_rec.olw_unit_price = inventory_master_rec.im_unit_price
    order_line_work_rec.olw_extended_price = (
        order_line_work_rec.olw_qty_requested * order_line_work_rec.olw_unit_price
    ).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def main():
    # Sample data for demonstration
    class Warehouse:
        def __init__(self, location_code, qty_on_hand, qty_allocated, qty_available, bin_number):
            self.wh_location_code = location_code
            self.wh_qty_on_hand = qty_on_hand
            self.wh_qty_allocated = qty_allocated
            self.wh_qty_available = qty_available
            self.wh_bin_number = bin_number

    wh1 = Warehouse('WH001', 100, 10, 90, 'BIN1')
    wh2 = Warehouse('WH002', 50, 5, 45, 'BIN2')
    inv = InvmastModel(
        im_item_id='ITEM001',
        im_item_desc='Test Item',
        im_category_code='E',
        im_unit_cost=Decimal('10.00'),
        im_unit_price=Decimal('25.00'),
        im_reorder_point=20,
        im_reorder_qty=50,
        im_warehouse_count=2,
        im_warehouse_table=[wh1, wh2],
        im_status_code='A',
        im_lead_time_days=5,
        im_vendor_id='VEND001',
        im_last_receipt_date=20230101,
        im_last_count_date=20230101
    )
    ord = OrdlineModel(
        olw_item_id='ITEM001',
        olw_qty_requested=100,
        olw_qty_available=0,
        olw_unit_price=Decimal('0.00'),
        olw_extended_price=Decimal('0.00'),
        olw_result_code=''
    )
    invchk(inv, ord)
    # No print statements to match COBOL behavior


if __name__ == '__main__':
    main()
