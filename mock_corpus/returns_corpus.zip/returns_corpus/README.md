# Returns/Exchange Corpus — 3-Tier Deep Chain, All Files Large

This is the "more files" escalation of `hybrid_corpus/`: instead of one
driver calling 3 large leaf programs (1 level of fan-in), this project is a
**3-tier call chain** — 7 program files total, every one of them individually
over 100 lines. It combines both prior stress dimensions (deep dependency
chain + large single files) at greater scale and depth than either
`perf_corpus/` or `hybrid_corpus/` alone.

## Structure

```
Tier 0 (driver):        RMADRIVE.CBL (124 lines)
                         |
              +----------+----------+
              |                     |
Tier 1 (mid):  RETNPROC.CBL (113)    EXCHPROC.CBL (114)
              |         |             |          |
Tier 2 (leaf): WARRCHK   REFCALC      RESTOCK    FRAUDRET
               (122)     (110)        (114)      (117)
```

RMADRIVE builds two sample RMAs (one straight return, one exchange) and
dispatches each by `RMA-REQUEST-TYPE`:
- **Return path**: RMADRIVE → RETNPROC → (WARRCHK, REFCALC)
- **Exchange path**: RMADRIVE → EXCHPROC → (RESTOCK, FRAUDRET)

## Copybooks (2)

| File | Purpose |
|---|---|
| RMAMAST.CPY | RMA header + `OCCURS 10` line-item table, passed whole between RMADRIVE and the tier-1 (mid) programs |
| MSGS4.CPY | Shared message constants |

## Design choices worth noting

- **No `REDEFINES`-packed lookup tables this time.** `perf_corpus` and
  `hybrid_corpus` both used hand-computed fixed-width digit strings for
  lookup tables (tax brackets, carrier rates, etc.), and I got the digit math
  wrong twice while building those. Every lookup table here (category
  fee %, warranty windows, state tax rates, fraud value thresholds) is
  instead populated via explicit `MOVE` statements in a `LOAD-*` paragraph —
  functionally equivalent for testing purposes, zero arithmetic-transcription
  risk.
- **`FUNCTION INTEGER-OF-DATE`** is used for real day-count math (warranty
  window, fraud quick-flip detection) instead of another packed table —
  a different intrinsic-function pattern than anything in the prior two
  corpora.
- Leaf programs take **scalar parameters** (item category, unit price, etc.)
  rather than whole nested records — this sidesteps the "01-level record
  copied under an OCCURS group" structural problem that had to be fixed
  in `perf_corpus`'s GLACCT.CPY, while the **mid-tier and driver programs
  do** pass the whole `RMA-HEADER-REC` by reference, since that record sits
  at the top of LINKAGE/WORKING-STORAGE directly (not nested under another
  OCCURS group) — the same safe pattern `perf_corpus`'s CUSTVAL/INVCHK used
  successfully.

## Bugs I introduced and fixed before delivering (for transparency)

1. Used `GO TO` out of a single-paragraph `PERFORM` (no `THRU`) in an early
   draft of a sibling project's WHCHECK.CBL-style guard clause — this breaks
   the implicit return stack and causes runaway fall-through in real COBOL.
   Rewritten as a plain `IF` guard instead.
2. `RMAMAST.CPY`'s `RL-RESTOCK-FEE` was declared `PIC 9(5)V99` while
   `RESTOCK.CBL` and `REFCALC.CBL`'s LINKAGE sections both expect
   `PIC 9(7)V99` for the same field — the exact class of interface
   mismatch that broke `GLPOST`/`ORDPROC` in the first migration run of
   `perf_corpus`. Fixed by aligning the copybook to `9(7)V99`. Every
   `CALL ... USING` argument list in this project has been cross-checked
   against its callee's `PROCEDURE DIVISION USING` signature by hand.

## Notes on correctness

No GnuCOBOL compiler is available in this environment to compile-check
these files. Run `cobc -x -Wall -I copybooks programs/RMADRIVE.CBL` (and the
same for each of the other 6 files, compiling leaves first) before treating
this as a clean baseline.
