# Order-to-Cash Performance Test Corpus

A larger, deeper COBOL project for stress-testing the migration system's
translation prompt size, dependency-context accumulation, and batch
orchestration — roughly 3x the size of the existing `mock_corpus/`
(897 lines vs. ~280), with a deeper call graph (6-way fan-in vs. the
original's max 2-way).

## Copybooks (7)

| File | Exercises |
|---|---|
| CUSTMAST.CPY | Nested customer record, credit/risk 88-levels, financial PIC 9(9)V99 fields |
| INVMAST.CPY | Nested warehouse `OCCURS 10` table with `INDEXED BY` |
| ORDHDR.CPY | `OCCURS 1 TO 100 TIMES DEPENDING ON` variable-length line-item table |
| ORDLINE.CPY | Standalone working-storage line record (used by INVCHK) |
| VENDMAST.CPY | Vendor master, rating 88-levels |
| GLACCT.CPY | GL posting entry, debit/credit 88-levels |
| MSGS.CPY | Shared message constants + return-code 88-levels |

## Programs (8)

| Program | Features | Lines | Calls |
|---|---|---|---|
| CUSTVAL.CBL | LINKAGE, EVALUATE TRUE, COMPUTE ROUNDED, credit-limit logic | 80 | — |
| INVCHK.CBL | PERFORM VARYING over warehouse OCCURS table | 61 | — |
| PRICECALC.CBL | Tiered EVALUATE discount table, COMPUTE ROUNDED chains | 67 | — |
| TAXCALC.CBL | `REDEFINES` state-rate table, table search via PERFORM VARYING | 64 | — |
| INVUPDATE.CBL | Multi-warehouse allocation loop, nested PERFORM | 69 | — |
| GLPOST.CBL | OCCURS output table, 4 posting-entry builder paragraphs | 89 | — |
| **ORDPROC.CBL** | **Driver — calls all 6 programs above**, large working-storage, deep dependency context | 160 | CUSTVAL, INVCHK, PRICECALC, TAXCALC, INVUPDATE, GLPOST |
| RPTGEN.CBL | Standalone, `FUNCTION MOD`, nested loops over `OCCURS DEPENDING ON` table, running totals | 128 | — |

## Dependency Graph

```
CUSTVAL, INVCHK, PRICECALC, TAXCALC, INVUPDATE, GLPOST ──called-by── ORDPROC
RPTGEN (standalone, no CALLs)
```

## Batch Migration Order (topological, filtered)

1. CUSTVAL
2. INVCHK
3. PRICECALC
4. TAXCALC
5. INVUPDATE
6. GLPOST
7. RPTGEN
8. ORDPROC — calls all 6 above; last in order, largest dependency context

## Why this stresses the system

- **Translation prompt size**: ORDPROC's `{dependency_context}` injection carries
  LINKAGE signatures from *six* upstream programs simultaneously — the current
  corpus never exceeds two. Combined with `{shared_model_code}` for 7 copybooks,
  this is the most likely candidate to reproduce or exceed the known
  32,768-output-token truncation issue.
- **OCCURS DEPENDING ON**: ORDHDR.CPY's variable-length table (`1 TO 100 TIMES`)
  isn't exercised anywhere in the existing corpus and is a good test of the
  interface extractor's `FIELD_RE`/`LINKAGE_SECTION_RE` regexes.
- **REDEFINES**: TAXCALC.CBL redefines a VALUE-initialized table as an indexed
  array — a pattern not present in the current corpus.
- **Deep GL posting fan-out**: GLPOST builds 4 output rows into a caller-owned
  OCCURS table passed by reference — tests whether the translator correctly
  models mutation-through-parameter for table structures.
- **Nested/standalone complexity without CALL**: RPTGEN has no dependencies but
  is deliberately loop-heavy (`FUNCTION MOD`, running category totals, average
  calculation) to test whether large *single-program* translations also hit
  token or correctness limits independent of dependency-context size.

## Changelog

**v2 — GnuCOBOL compile fixes** (after real batch-migration run surfaced these):

1. `ORDHDR.CPY` — the `OCCURS ... DEPENDING ON` line-item table had four trailing
   fields (`OH-SUBTOTAL`, `OH-TAX-TOTAL`, `OH-FREIGHT-AMT`, `OH-ORDER-TOTAL`,
   `OH-SHIP-TO-STATE`, `OH-SALES-REP-ID`) declared *after* it. A variable-occurrence
   table must be the last item in its record — this isn't a GnuCOBOL quirk, it's
   a standard COBOL rule (IBM Enterprise COBOL enforces it too; the earlier
   version just hadn't been compile-tested). Fixed by moving those fields ahead
   of `OH-ORDER-LINES`.
2. `GLPOST.CBL` and `ORDPROC.CBL` — both declared their 4-entry GL-postings table
   as an `OCCURS` item directly at the 01 level and passed it straight into
   `PROCEDURE DIVISION USING` / `CALL ... USING`. GnuCOBOL wants a subscript on
   an 01-level occurring item referenced that way. Fixed by wrapping the table
   one level deeper under a parent group (`LS-GL-ENTRIES-GROUP` /
   `WS-GL-ENTRIES-GROUP`) and passing the group instead — a more conventional
   structure anyway. All elementary field references inside GLPOST's paragraphs
   (`GL-ACCOUNT-NUMBER(WS-ENTRY-COUNT)`, etc.) were untouched since the field
   names and indexing didn't change.

## Notes on correctness

These programs were hand-written to be syntactically valid GnuCOBOL 3.2. A real
batch migration run against a GnuCOBOL container caught the three issues above,
which are now fixed. The other 5 programs (PRICECALC, TAXCALC, CUSTVAL, INVCHK,
INVUPDATE) compiled and translated successfully on the first pass.
