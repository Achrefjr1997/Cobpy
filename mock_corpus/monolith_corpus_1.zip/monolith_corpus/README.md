# Monolith Corpus — Single Large-File Performance Test

Where `perf_corpus/` stress-tested a **deep dependency chain** across many
small/medium programs (one driver calling six subprograms), this project
tests the opposite failure mode: **a single COBOL program that is large on
its own**, with no `CALL`s and no dependency-context splitting to fall back
on. Everything the migration agent needs — data understanding, translation,
test generation — has to happen against one big `{analysis_context}` and one
big single-shot translation.

## Programs (2, both standalone — no CALLs)

| Program | Lines | Exercises |
|---|---|---|
| PAYROLL.CBL | 347 | Inline nested `OCCURS`-within-`OCCURS` employee/deduction table, `REDEFINES` state-rate table, `REDEFINES` federal tax-bracket table with reverse `PERFORM VARYING ... BY -1` bracket lookup, tiered EVALUATE gross-pay logic (hourly+overtime vs. salaried), FICA wage-cap logic, Medicare additional-rate threshold, percent vs. fixed deduction processing, YTD accumulation, batch summary reporting |
| BILLING.CBL | 278 | Nested `OCCURS`-within-`OCCURS` customer/invoice table, `REDEFINES` late-fee tier table, aging-bucket EVALUATE (current/31-60/61-90/90+), reverse tier lookup for late fees, credit-hold and credit-limit-breach logic, per-customer and batch-level rollups |

## Copybooks (3)

| File | Purpose |
|---|---|
| EMPMAST.CPY | Canonical employee-record shape (01-level, with its own nested `OCCURS` deduction/dependent tables). Kept as a reference/standalone record — **not** `COPY`'d directly into PAYROLL.CBL's working storage, since a 01-level copybook record can't be nested under a 05-level `OCCURS` group (the same structural issue documented in `perf_corpus/README.md` for GLACCT.CPY). PAYROLL.CBL declares its own inline employee table with matching field names instead. |
| PAYTABLE.CPY | Federal tax-bracket `REDEFINES` table used by PAYROLL.CBL |
| MSGS2.CPY | Shared message constants used by both programs |

## Why this stresses the system differently than perf_corpus

- **No dependency_interfaces to lean on.** In perf_corpus, ORDPROC's prompt at
  least had structured LINKAGE signatures from upstream programs to anchor
  the translation. Here there's nothing upstream — the whole 300+ line
  program has to be understood and translated in one pass.
- **Two independent reverse-lookup patterns** (bracket table via
  `PERFORM VARYING ... FROM n BY -1`, tier table via the same pattern in
  BILLING) are a good test of whether the translator preserves "highest
  matching threshold" semantics rather than just literally transliterating
  the loop.
- **Deeply nested OCCURS** (table-within-table, e.g.
  `EM-DEDUCTION-TABLE` nested inside `EM-ENTRY`, both subscripted together as
  `DED-AMOUNT(EMP-IDX, WS-DED-SUB)`) is a heavier structural case than
  anything in perf_corpus, which only nested one level deep.
- **Both programs are long enough on their own** that if the known
  32,768-output-token truncation issue reproduces here, it confirms the
  problem isn't specific to dependency-context size — it's just about raw
  program length/complexity.

## Notes on correctness

Hand-written and hand-verified (including recomputing all fixed-width
`REDEFINES` digit strings — the perf_corpus project's first draft got this
wrong once already, so these were double-checked digit-by-digit). No
GnuCOBOL compiler is available in this environment to compile-check them —
run `cobc -x -Wall -I copybooks programs/PAYROLL.CBL` (and the same for
BILLING.CBL) before treating this as a clean baseline.
