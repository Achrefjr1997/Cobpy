from shared_models import MSG4_FRAUD_SUSPECTED

def fraudret(customer_returns, condition_code, days_since_purchase, unit_price, return_qty):
    score = 0
    hold_flag = 'N'

    # Thresholds: (floor, points) in ascending order
    thresholds = [
        (500.00, 10),
        (1500.00, 25),
        (5000.00, 45)
    ]

    # Return frequency scoring
    if customer_returns > 20:
        score += 50
    elif customer_returns > 10:
        score += 30
    elif customer_returns > 5:
        score += 10

    # Condition mismatch
    if condition_code == 'D' and days_since_purchase < 3:
        score += 20

    # Quick flip
    if days_since_purchase < 2:
        score += 5

    # High-value scoring: only the highest threshold met is used
    line_value = round(unit_price * return_qty, 2)
    value_points = 0
    for floor, points in reversed(thresholds):
        if line_value >= floor:
            if value_points == 0:
                value_points = points
            break
    score += value_points

    # Finalize: cap at 999, set hold flag and display message if >= 50
    if score > 999:
        score = 999
    if score >= 50:
        hold_flag = 'Y'
        print(MSG4_FRAUD_SUSPECTED)
    else:
        hold_flag = 'N'

    return score, hold_flag

def main():
    # Example call to demonstrate functionality
    fraudret(25, 'D', 1, 100.00, 5)

if __name__ == "__main__":
    main()
