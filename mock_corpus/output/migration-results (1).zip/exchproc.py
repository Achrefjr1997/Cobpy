from datetime import date
from decimal import Decimal
from shared_models import RmamastModel, MSG4_LINE_REJECTED, MSG4_RMA_APPROVED, MSG4_RMA_PARTIAL, MSG4_RMA_REJECTED
from restock import calculate_restock_fee
from fraudret import fraudret


def exchproc(rma: RmamastModel) -> None:
    rma.rma_total_refund = Decimal('0')
    rma.rma_total_restock_fees = Decimal('0')
    approved_count = 0
    rejected_count = 0

    today = date.today()

    for line in rma.rma_line_table:
        line.rl_warranty_status = 'F'

        restock_fee = calculate_restock_fee(
            line.rl_item_category,
            line.rl_condition_code,
            line.rl_unit_price,
            line.rl_return_qty,
            line.rl_warranty_status
        )
        line.rl_restock_fee = restock_fee

        purchase_str = str(line.rl_purchase_date)
        purchase_date = date(int(purchase_str[:4]), int(purchase_str[4:6]), int(purchase_str[6:8]))
        days = (today - purchase_date).days
        if days < 0:
            days = 0

        fraud_score, fraud_hold_flag = fraudret(
            3,
            line.rl_condition_code,
            days,
            line.rl_unit_price,
            line.rl_return_qty
        )
        line.rl_fraud_score = fraud_score

        if fraud_hold_flag == 'Y':
            line.rl_line_result = 'R'
        else:
            line.rl_line_result = 'A'

        print(f"  ITEM:            {line.rl_item_id}")
        print(f"  CATEGORY:        {line.rl_item_category}")
        print(f"  CONDITION:       {line.rl_condition_code}")
        print(f"  RESTOCK FEE:     {int(line.rl_restock_fee * 100):09d}")
        print(f"  FRAUD SCORE:     {line.rl_fraud_score:03d}")
        print(f"  LINE RESULT:     {line.rl_line_result}")

        if line.rl_line_result == 'A':
            approved_count += 1
            rma.rma_total_restock_fees += line.rl_restock_fee
        else:
            rejected_count += 1
            msg = MSG4_LINE_REJECTED.ljust(40)
            print(f"{msg} ITEM: {line.rl_item_id}")

    if rejected_count == 0:
        rma.rma_overall_status = 'A'
        print(MSG4_RMA_APPROVED.ljust(40))
    elif approved_count == 0:
        rma.rma_overall_status = 'R'
        print(MSG4_RMA_REJECTED.ljust(40))
    else:
        rma.rma_overall_status = 'P'
        print(MSG4_RMA_PARTIAL.ljust(40))


def main():
    rma = RmamastModel(
        rma_number='RMA123456789',
        rma_customer_id='CUST0001',
        rma_original_order_num='ORD987654321',
        rma_request_date=20240101,
        rma_request_type='X',
        rma_reason_code='01',
        rma_ship_to_state='CA',
        rma_line_count=2,
        rma_line_table=[
            {
                'rl_item_id': 'ITEM00000001',
                'rl_item_category': 'EL',
                'rl_original_qty': 1,
                'rl_return_qty': 1,
                'rl_unit_price': Decimal('199.99'),
                'rl_purchase_date': 20231215,
                'rl_condition_code': 'N',
                'rl_warranty_status': ' ',
                'rl_restock_fee': Decimal('0'),
                'rl_refund_amount': Decimal('0'),
                'rl_fraud_score': 0,
                'rl_line_result': ' '
            },
            {
                'rl_item_id': 'ITEM00000002',
                'rl_item_category': 'CL',
                'rl_original_qty': 2,
                'rl_return_qty': 1,
                'rl_unit_price': Decimal('49.50'),
                'rl_purchase_date': 20240110,
                'rl_condition_code': 'O',
                'rl_warranty_status': ' ',
                'rl_restock_fee': Decimal('0'),
                'rl_refund_amount': Decimal('0'),
                'rl_fraud_score': 0,
                'rl_line_result': ' '
            }
        ],
        rma_total_refund=Decimal('0'),
        rma_total_restock_fees=Decimal('0'),
        rma_overall_status=' '
    )
    exchproc(rma)


if __name__ == '__main__':
    main()
