from pydantic import BaseModel
from decimal import Decimal

MSG4_WARRANTY_EXPIRED: str = 'WARRANTY WINDOW HAS EXPIRED'
MSG4_WARRANTY_FULL: str = 'FULL WARRANTY COVERAGE APPLIES'
MSG4_WARRANTY_LIMITED: str = 'LIMITED WARRANTY - RESTOCK FEE APPLIES'
MSG4_FRAUD_SUSPECTED: str = 'RETURN FLAGGED - POSSIBLE FRAUD PATTERN'
MSG4_LINE_REJECTED: str = 'LINE ITEM REJECTED'
MSG4_RMA_APPROVED: str = 'RMA APPROVED'
MSG4_RMA_PARTIAL: str = 'RMA PARTIALLY APPROVED'
MSG4_RMA_REJECTED: str = 'RMA REJECTED'
MSG4_BATCH_COMPLETE: str = 'RETURNS BATCH COMPLETE'

class RmamastModel(BaseModel):
    """Generated from RMAMAST."""

    rma_number: str  # PIC X(12)
    rma_customer_id: str  # PIC X(08)
    rma_original_order_num: str  # PIC X(12)
    rma_request_date: int  # PIC 9(8)
    rma_request_type: str  # PIC X(01)
    rma_reason_code: str  # PIC X(02)
    rma_ship_to_state: str  # PIC X(02)
    rma_line_count: int  # PIC 9(2)
    rma_line_table: str  # PIC OCCURS
    rl_item_id: str  # PIC X(12)
    rl_item_category: str  # PIC X(02)
    rl_original_qty: int  # PIC 9(4)
    rl_return_qty: int  # PIC 9(4)
    rl_unit_price: Decimal  # PIC 9(7)V99
    rl_purchase_date: int  # PIC 9(8)
    rl_condition_code: str  # PIC X(01)
    rl_warranty_status: str  # PIC X(01)
    rl_restock_fee: Decimal  # PIC 9(7)V99
    rl_refund_amount: Decimal  # PIC 9(7)V99
    rl_fraud_score: int  # PIC 9(3)
    rl_line_result: str  # PIC X(01)
    rma_total_refund: Decimal  # PIC 9(9)V99
    rma_total_restock_fees: Decimal  # PIC 9(7)V99
    rma_overall_status: str  # PIC X(01)