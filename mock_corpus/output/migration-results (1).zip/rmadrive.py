from decimal import Decimal
from shared_models import RmamastModel, MSG4_BATCH_COMPLETE
from retnproc import process_rma
from exchproc import exchproc

DASH_LINE = '=' * 72

class LineItem:
    def __init__(self):
        self.rl_item_id = ''
        self.rl_item_category = ''
        self.rl_original_qty = 0
        self.rl_return_qty = 0
        self.rl_unit_price = Decimal('0')
        self.rl_purchase_date = 0
        self.rl_condition_code = ''
        self.rl_warranty_status = ''
        self.rl_restock_fee = Decimal('0')
        self.rl_refund_amount = Decimal('0')
        self.rl_fraud_score = 0
        self.rl_line_result = ''

def main():
    # Build return RMA
    return_lines = [LineItem() for _ in range(10)]
    return_lines[0].rl_item_id = 'ITEM000101'
    return_lines[0].rl_item_category = 'EL'
    return_lines[0].rl_original_qty = 1
    return_lines[0].rl_return_qty = 1
    return_lines[0].rl_unit_price = Decimal('249.99')
    return_lines[0].rl_purchase_date = 20260610
    return_lines[0].rl_condition_code = 'N'
    return_lines[1].rl_item_id = 'ITEM000205'
    return_lines[1].rl_item_category = 'CL'
    return_lines[1].rl_original_qty = 2
    return_lines[1].rl_return_qty = 2
    return_lines[1].rl_unit_price = Decimal('39.99')
    return_lines[1].rl_purchase_date = 20250101
    return_lines[1].rl_condition_code = 'O'

    return_rma = RmamastModel(
        rma_number='RMA-000001R1',
        rma_customer_id='CUST0042',
        rma_original_order_num='ORD-2026-0091',
        rma_request_date=20260701,
        rma_request_type='R',
        rma_reason_code='DR',
        rma_ship_to_state='CA',
        rma_line_count=2,
        rma_line_table=return_lines,
        rma_total_refund=Decimal('0'),
        rma_total_restock_fees=Decimal('0'),
        rma_overall_status=''
    )

    # Build exchange RMA
    exchange_lines = [LineItem() for _ in range(10)]
    exchange_lines[0].rl_item_id = 'ITEM000310'
    exchange_lines[0].rl_item_category = 'FU'
    exchange_lines[0].rl_original_qty = 1
    exchange_lines[0].rl_return_qty = 1
    exchange_lines[0].rl_unit_price = Decimal('899.00')
    exchange_lines[0].rl_purchase_date = 20260718
    exchange_lines[0].rl_condition_code = 'O'

    exchange_rma = RmamastModel(
        rma_number='RMA-000002X1',
        rma_customer_id='CUST0077',
        rma_original_order_num='ORD-2026-0134',
        rma_request_date=20260715,
        rma_request_type='X',
        rma_reason_code='SZ',
        rma_ship_to_state='NY',
        rma_line_count=1,
        rma_line_table=exchange_lines,
        rma_total_refund=Decimal('0'),
        rma_total_restock_fees=Decimal('0'),
        rma_overall_status=''
    )

    # Batch counters and totals
    approved_count = 0
    partial_count = 0
    rejected_count = 0
    total_refund = Decimal('0')
    total_restock_fees = Decimal('0')

    # Print header
    print(DASH_LINE)
    print('RETURNS AND EXCHANGE BATCH RUN')
    print(DASH_LINE)

    # Process return RMA
    process_rma(return_rma)
    if return_rma.rma_overall_status == 'A':
        approved_count += 1
    elif return_rma.rma_overall_status == 'P':
        partial_count += 1
    else:
        rejected_count += 1
    total_refund += return_rma.rma_total_refund
    total_restock_fees += return_rma.rma_total_restock_fees

    # Process exchange RMA
    exchproc(exchange_rma)
    if exchange_rma.rma_overall_status == 'A':
        approved_count += 1
    elif exchange_rma.rma_overall_status == 'P':
        partial_count += 1
    else:
        rejected_count += 1
    total_refund += exchange_rma.rma_total_refund
    total_restock_fees += exchange_rma.rma_total_restock_fees

    # Print final summary
    print(DASH_LINE)
    print('BATCH SUMMARY')
    print(f'RMAs APPROVED:       {approved_count}')
    print(f'RMAs PARTIAL:        {partial_count}')
    print(f'RMAs REJECTED:       {rejected_count}')
    print(f'TOTAL REFUNDED:      {total_refund}')
    print(f'TOTAL RESTOCK FEES:  {total_restock_fees}')
    print(MSG4_BATCH_COMPLETE)
    print(DASH_LINE)

if __name__ == '__main__':
    main()