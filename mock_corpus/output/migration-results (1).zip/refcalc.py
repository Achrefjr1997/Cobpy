def refcalc(unit_price, return_qty, ship_to_state, restock_fee, warranty_status):
    # State tax rates
    state_tax_rates = {
        'CA': 0.0725,
        'NY': 0.0400,
        'TX': 0.0625,
        'FL': 0.0600,
        'WA': 0.0650,
        'OR': 0.0000
    }
    # Find applicable tax rate
    tax_rate = state_tax_rates.get(ship_to_state, 0.0)
    
    # Calculate gross line value
    gross = round(unit_price * return_qty, 2)
    # Tax portion
    tax = round(gross * tax_rate, 2)
    # Refund before restock fee
    refund_before_fee = round(gross + tax, 2)
    # Final refund after restock fee
    final_refund = round(refund_before_fee - restock_fee, 2)
    if final_refund < 0:
        final_refund = 0.0
    
    # Warranty expired handling
    if warranty_status == 'E':
        final_refund = 0.0
        tax = 0.0
        print('WARRANTY WINDOW HAS EXPIRED')
    
    return final_refund, tax


def main():
    # Example usage
    unit_price = 100.00
    return_qty = 2
    ship_to_state = 'CA'
    restock_fee = 10.00
    warranty_status = 'F'  # not expired
    refund, tax_refunded = refcalc(unit_price, return_qty, ship_to_state, restock_fee, warranty_status)
    print(f"Refund: {refund}, Tax Refunded: {tax_refunded}")


if __name__ == '__main__':
    main()