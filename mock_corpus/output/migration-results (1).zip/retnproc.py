from decimal import Decimal
from shared_models import (
    RmamastModel,
    MSG4_LINE_REJECTED,
    MSG4_RMA_APPROVED,
    MSG4_RMA_PARTIAL,
    MSG4_RMA_REJECTED,
)
from warrchk import warranty_check
from refcalc import refcalc


def process_rma(rma: RmamastModel) -> None:
    rma.rma_total_refund = Decimal('0')
    rma.rma_total_restock_fees = Decimal('0')
    approved_count = 0
    rejected_count = 0

    print(f'--- PROCESSING RETURN RMA: {rma.rma_number} ---')
    print(f'CUSTOMER:      {rma.rma_customer_id}')
    print(f'ORIGINAL ORDER:{rma.rma_original_order_num}')
    print(f'LINE COUNT:    {rma.rma_line_count}')

    for i in range(rma.rma_line_count):
        line = rma.rma_line_table[i]

        warranty_status, _ = warranty_check(
            line.rl_item_category,
            line.rl_purchase_date,
            line.rl_condition_code
        )
        line.rl_warranty_status = warranty_status

        refund_amount, _ = refcalc(
            line.rl_unit_price,
            line.rl_return_qty,
            rma.rma_ship_to_state,
            line.rl_restock_fee,
            line.rl_warranty_status
        )
        line.rl_refund_amount = refund_amount

        if line.rl_warranty_status == 'E' and line.rl_condition_code == 'D':
            line.rl_line_result = 'R'
        else:
            line.rl_line_result = 'A'

        print(f'  ITEM:            {line.rl_item_id}')
        print(f'  CATEGORY:        {line.rl_item_category}')
        print(f'  CONDITION:       {line.rl_condition_code}')
        print(f'  WARRANTY STATUS: {line.rl_warranty_status}')
        print(f'  RESTOCK FEE:     {line.rl_restock_fee}')
        print(f'  REFUND AMOUNT:   {line.rl_refund_amount}')
        print(f'  LINE RESULT:     {line.rl_line_result}')

        if line.rl_line_result == 'A':
            approved_count += 1
            rma.rma_total_refund += line.rl_refund_amount
            rma.rma_total_restock_fees += line.rl_restock_fee
        else:
            rejected_count += 1
            print(f'{MSG4_LINE_REJECTED} ITEM: {line.rl_item_id}')

    if rejected_count == 0:
        rma.rma_overall_status = 'A'
        print(MSG4_RMA_APPROVED)
    elif approved_count == 0:
        rma.rma_overall_status = 'R'
        print(MSG4_RMA_REJECTED)
    else:
        rma.rma_overall_status = 'P'
        print(MSG4_RMA_PARTIAL)

    print(f'LINES APPROVED: {approved_count}')
    print(f'LINES REJECTED: {rejected_count}')
    print(f'TOTAL REFUND:   {rma.rma_total_refund}')
    print(f'OVERALL STATUS: {rma.rma_overall_status}')


def main():
    # Example usage would create an RmamastModel instance and call process_rma
    pass


if __name__ == '__main__':
    main()
