from decimal import Decimal, ROUND_HALF_UP

def calculate_restock_fee(item_category, condition_code, unit_price, return_qty, warranty_status):
    # Base fee percentages by category
    category_fees = {
        'EL': Decimal('15.00'),
        'AP': Decimal('10.00'),
        'FU': Decimal('20.00'),
        'CL': Decimal('0.00'),
        'GN': Decimal('5.00')
    }
    base_fee_pct = category_fees.get(item_category, Decimal('5.00'))

    # Condition multiplier
    if condition_code == 'N':
        multiplier = Decimal('0.00')
    elif condition_code == 'O':
        multiplier = Decimal('1.00')
    elif condition_code == 'D':
        multiplier = Decimal('2.00')
    else:
        multiplier = Decimal('1.00')

    # Full warranty overrides condition multiplier
    if warranty_status == 'F':
        multiplier = Decimal('0.00')

    # Extended value = unit price * quantity, rounded to 2 decimals
    extended_value = (unit_price * return_qty).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    # Fee percentage = base * multiplier, rounded to 2 decimals, capped at 50%
    fee_pct = (base_fee_pct * multiplier).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    if fee_pct > Decimal('50.00'):
        fee_pct = Decimal('50.00')

    # Final fee amount, rounded to 2 decimals
    fee_amount = (extended_value * fee_pct / Decimal('100')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    if fee_amount > 0:
        print(f'RESTOCK FEE APPLIED: {fee_amount}')

    return fee_amount


def main():
    # Example usage
    fee = calculate_restock_fee('EL', 'O', Decimal('100.00'), 2, 'L')
    print(f'Restock fee: {fee}')


if __name__ == '__main__':
    main()
