import datetime

MSG4_WARRANTY_EXPIRED = 'WARRANTY WINDOW HAS EXPIRED'
MSG4_WARRANTY_FULL = 'FULL WARRANTY COVERAGE APPLIES'
MSG4_WARRANTY_LIMITED = 'LIMITED WARRANTY - RESTOCK FEE APPLIES'

CATEGORY_WINDOWS = {
    'EL': (90, 365),
    'AP': (30, 180),
    'FU': (60, 730),
    'CL': (14, 60),
    'GN': (30, 90),
}

def warranty_check(item_category, purchase_date, condition_code):
    purchase_str = str(purchase_date).zfill(8)
    purchase_dt = datetime.date(int(purchase_str[:4]), int(purchase_str[4:6]), int(purchase_str[6:8]))
    today = datetime.date.today()
    days_elapsed = (today - purchase_dt).days
    if days_elapsed < 0:
        days_elapsed = 0

    full_days, limited_days = CATEGORY_WINDOWS.get(item_category, (30, 90))

    if condition_code == 'D':
        status = 'E'
        print(MSG4_WARRANTY_EXPIRED)
    elif days_elapsed <= full_days:
        status = 'F'
        print(MSG4_WARRANTY_FULL)
    elif days_elapsed <= limited_days:
        status = 'L'
        print(MSG4_WARRANTY_LIMITED)
    else:
        status = 'E'
        print(MSG4_WARRANTY_EXPIRED)

    return status, days_elapsed

def main():
    warranty_check('EL', 20230101, 'N')

if __name__ == '__main__':
    main()
