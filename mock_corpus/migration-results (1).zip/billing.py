from decimal import Decimal, ROUND_HALF_UP

MSG2_INVOICE_PAST_DUE = 'INVOICE PAST DUE - LATE FEE APPLIED'
MSG2_CUSTOMER_ON_HOLD = 'CUSTOMER ON CREDIT HOLD'
MSG2_BATCH_COMPLETE = 'BATCH PROCESSING COMPLETE'

LATE_FEE_TIERS = [
    (0, Decimal('3.00')),
    (31, Decimal('8.00')),
    (61, Decimal('15.00')),
    (91, Decimal('25.00'))
]

def load_sample_customers():
    customers = []
    # Customer 1
    cust1 = {
        'id': 'CUST0001',
        'name': 'ACME MANUFACTURING',
        'credit_hold': 'N',
        'credit_limit': Decimal('50000.00'),
        'invoices': [
            {'number': 'INV-000101', 'amount': Decimal('4500.00'), 'days_old': 15, 'paid': 'N'},
            {'number': 'INV-000102', 'amount': Decimal('1200.00'), 'days_old': 75, 'paid': 'N'}
        ]
    }
    customers.append(cust1)

    # Customer 2
    cust2 = {
        'id': 'CUST0002',
        'name': 'NORTHWIND TRADERS',
        'credit_hold': 'N',
        'credit_limit': Decimal('25000.00'),
        'invoices': [
            {'number': 'INV-000201', 'amount': Decimal('8000.00'), 'days_old': 5, 'paid': 'N'},
            {'number': 'INV-000202', 'amount': Decimal('6500.00'), 'days_old': 95, 'paid': 'N'},
            {'number': 'INV-000203', 'amount': Decimal('3000.00'), 'days_old': 40, 'paid': 'Y'}
        ]
    }
    customers.append(cust2)

    # Customer 3
    cust3 = {
        'id': 'CUST0003',
        'name': 'DELINQUENT DISTRIBUTORS',
        'credit_hold': 'Y',
        'credit_limit': Decimal('10000.00'),
        'invoices': [
            {'number': 'INV-000301', 'amount': Decimal('9800.00'), 'days_old': 120, 'paid': 'N'}
        ]
    }
    customers.append(cust3)

    # Customer 4
    cust4 = {
        'id': 'CUST0004',
        'name': 'GOOD STANDING LLC',
        'credit_hold': 'N',
        'credit_limit': Decimal('100000.00'),
        'invoices': [
            {'number': 'INV-000401', 'amount': Decimal('2500.00'), 'days_old': 3, 'paid': 'N'}
        ]
    }
    customers.append(cust4)
    return customers

def print_dash_line():
    print('-' * 72)

def determine_aging_bucket(days_old):
    if days_old <= 30:
        return 'current'
    elif days_old <= 60:
        return '30_day'
    elif days_old <= 90:
        return '60_day'
    else:
        return '90_day'

def calculate_late_fee(amount, days_old):
    if days_old <= 30:
        return Decimal('0.00'), False
    # Find highest tier where days_old >= floor
    pct = Decimal('0.00')
    for floor, tier_pct in reversed(LATE_FEE_TIERS):
        if days_old >= floor:
            pct = tier_pct
            break
    fee = (amount * pct / Decimal('100')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return fee, True

def process_customers(customers):
    batch_total_billed = Decimal('0.00')
    batch_total_late_fees = Decimal('0.00')
    batch_total_current = Decimal('0.00')
    batch_total_30_day = Decimal('0.00')
    batch_total_60_day = Decimal('0.00')
    batch_total_90_day = Decimal('0.00')
    customers_on_hold_count = 0
    invoices_processed_count = 0

    print_dash_line()
    print('INVOICE AGING AND LATE FEE BATCH RUN')
    print_dash_line()

    for cust in customers:
        cust['total_current'] = Decimal('0.00')
        cust['total_30_day'] = Decimal('0.00')
        cust['total_60_day'] = Decimal('0.00')
        cust['total_90_day'] = Decimal('0.00')
        cust['total_due'] = Decimal('0.00')

        if cust['credit_hold'] == 'Y':
            print(MSG2_CUSTOMER_ON_HOLD)
            customers_on_hold_count += 1

        for inv in cust['invoices']:
            if inv['paid'] == 'Y':
                inv['late_fee'] = Decimal('0.00')
                inv['total_due'] = Decimal('0.00')
            else:
                invoices_processed_count += 1
                bucket = determine_aging_bucket(inv['days_old'])
                if bucket == 'current':
                    cust['total_current'] += inv['amount']
                elif bucket == '30_day':
                    cust['total_30_day'] += inv['amount']
                elif bucket == '60_day':
                    cust['total_60_day'] += inv['amount']
                else:
                    cust['total_90_day'] += inv['amount']

                late_fee, is_late = calculate_late_fee(inv['amount'], inv['days_old'])
                inv['late_fee'] = late_fee
                inv['total_due'] = (inv['amount'] + late_fee).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                cust['total_due'] += inv['total_due']
                if is_late:
                    print(MSG2_INVOICE_PAST_DUE)

        # Credit limit check
        if cust['total_due'] > cust['credit_limit'] and cust['credit_hold'] == 'N':
            cust['credit_hold'] = 'Y'
            print(f"CREDIT LIMIT BREACHED - PLACING ON HOLD: {cust['id']}")
            customers_on_hold_count += 1

        # Print customer detail
        print_dash_line()
        print(f"CUSTOMER: {cust['id']} {cust['name']}")
        print(f"CURRENT:     {cust['total_current']:.2f}")
        print(f"31-60 DAYS:  {cust['total_30_day']:.2f}")
        print(f"61-90 DAYS:  {cust['total_60_day']:.2f}")
        print(f"OVER 90:     {cust['total_90_day']:.2f}")
        print(f"TOTAL DUE:   {cust['total_due']:.2f}")
        print(f"ON HOLD:     {cust['credit_hold']}")

        # Update batch totals
        batch_total_billed += cust['total_due']
        batch_total_current += cust['total_current']
        batch_total_30_day += cust['total_30_day']
        batch_total_60_day += cust['total_60_day']
        batch_total_90_day += cust['total_90_day']
        for inv in cust['invoices']:
            batch_total_late_fees += inv['late_fee']

    # Print batch summary
    print_dash_line()
    print('BATCH SUMMARY')
    print(f"INVOICES PROCESSED:   {invoices_processed_count}")
    print(f"CUSTOMERS ON HOLD:    {customers_on_hold_count}")
    print(f"TOTAL CURRENT:        {batch_total_current:.2f}")
    print(f"TOTAL 31-60 DAY:      {batch_total_30_day:.2f}")
    print(f"TOTAL 61-90 DAY:      {batch_total_60_day:.2f}")
    print(f"TOTAL OVER 90 DAY:    {batch_total_90_day:.2f}")
    print(f"TOTAL LATE FEES:      {batch_total_late_fees:.2f}")
    print(f"TOTAL BILLED (W/FEES):{batch_total_billed:.2f}")
    print(MSG2_BATCH_COMPLETE)
    print_dash_line()

def main():
    customers = load_sample_customers()
    process_customers(customers)

if __name__ == '__main__':
    main()
