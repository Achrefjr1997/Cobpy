from decimal import Decimal, getcontext, ROUND_HALF_UP

# Constants
MSG2_EMPLOYEE_TERMINATED = 'EMPLOYEE IS TERMINATED - SKIPPING'
MSG2_EMPLOYEE_ON_LEAVE = 'EMPLOYEE ON LEAVE - NO PAY PROCESSED'
MSG2_NEGATIVE_NET_PAY = 'WARNING - NEGATIVE NET PAY CALCULATED'
MSG2_FICA_CAP_REACHED = 'FICA WAGE CAP REACHED THIS PERIOD'
MSG2_BATCH_COMPLETE = 'BATCH PROCESSING COMPLETE'

FICA_RATE = Decimal('0.0765')
FICA_WAGE_CAP = Decimal('168600.00')
MEDICARE_ADDL_RATE = Decimal('0.0090')
MEDICARE_ADDL_THRESHOLD = Decimal('200000.00')
EXEMPTION_AMOUNT_PER = Decimal('87.50')

# Federal tax brackets: (floor, rate%, base_tax)
FEDERAL_BRACKETS = [
    (Decimal('0.00'), Decimal('10.00'), Decimal('0.00')),
    (Decimal('11000.00'), Decimal('12.00'), Decimal('1200.00')),
    (Decimal('44000.00'), Decimal('18.00'), Decimal('2200.00')),
    (Decimal('95000.00'), Decimal('24.00'), Decimal('3700.00')),
    (Decimal('182000.00'), Decimal('32.00'), Decimal('5500.00')),
    (Decimal('231000.00'), Decimal('37.00'), Decimal('6000.00'))
]

# State tax rates: state_code -> rate%
STATE_RATES = {
    'CA': Decimal('5.25'),
    'NY': Decimal('4.85'),
    'TX': Decimal('0.00'),
    'FL': Decimal('0.00'),
    'WA': Decimal('0.00')
}

def rnd(val):
    """Round to 2 decimal places, half-up."""
    return val.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def load_employees():
    """Return list of employee dicts matching COBOL sample data."""
    employees = []
    # Employee 1
    emp1 = {
        'employee_id': 'EMP00001',
        'first_name': 'ALICE',
        'last_name': 'JOHNSON',
        'job_class': 'HR',
        'pay_rate': Decimal('32.50'),
        'annual_salary': Decimal('0'),
        'filing_status': 'S',
        'state_code': 'CA',
        'exemptions': 1,
        'status_code': 'A',
        'ytd_gross': Decimal('0'),
        'ytd_federal_tax': Decimal('0'),
        'ytd_state_tax': Decimal('0'),
        'ytd_fica': Decimal('0'),
        'ytd_net': Decimal('0'),
        'deduction_count': 1,
        'deductions': [
            {'code': 'D401', 'type': 'P', 'amount': Decimal('5.00')}
        ],
        'dependent_count': 0
    }
    employees.append(emp1)

    # Employee 2
    emp2 = {
        'employee_id': 'EMP00002',
        'first_name': 'BOB',
        'last_name': 'MARTINEZ',
        'job_class': 'SL',
        'pay_rate': Decimal('0'),
        'annual_salary': Decimal('95000.00'),
        'filing_status': 'M',
        'state_code': 'NY',
        'exemptions': 3,
        'status_code': 'A',
        'ytd_gross': Decimal('0'),
        'ytd_federal_tax': Decimal('0'),
        'ytd_state_tax': Decimal('0'),
        'ytd_fica': Decimal('0'),
        'ytd_net': Decimal('0'),
        'deduction_count': 2,
        'deductions': [
            {'code': 'HLTH', 'type': 'F', 'amount': Decimal('125.00')},
            {'code': 'D401', 'type': 'P', 'amount': Decimal('6.00')}
        ],
        'dependent_count': 2
    }
    employees.append(emp2)

    # Employee 3
    emp3 = {
        'employee_id': 'EMP00003',
        'first_name': 'CARLA',
        'last_name': 'NGUYEN',
        'job_class': 'EX',
        'pay_rate': Decimal('0'),
        'annual_salary': Decimal('240000.00'),
        'filing_status': 'H',
        'state_code': 'TX',
        'exemptions': 2,
        'status_code': 'T',
        'ytd_gross': Decimal('0'),
        'ytd_federal_tax': Decimal('0'),
        'ytd_state_tax': Decimal('0'),
        'ytd_fica': Decimal('0'),
        'ytd_net': Decimal('0'),
        'deduction_count': 0,
        'deductions': [],
        'dependent_count': 1
    }
    employees.append(emp3)

    return employees

def calculate_gross_pay(emp):
    """Return gross pay for one employee."""
    if emp['job_class'] == 'HR':
        hours = Decimal('40.00')
        overtime = Decimal('6.00')
        regular = rnd(hours * emp['pay_rate'])
        overtime_pay = rnd(overtime * emp['pay_rate'] * Decimal('1.5'))
        return rnd(regular + overtime_pay)
    elif emp['job_class'] in ('SL', 'EX'):
        return rnd(emp['annual_salary'] / Decimal('26'))
    else:
        return Decimal('0')

def calculate_exemption_amount(exemptions):
    """Return exemption amount and taxable gross."""
    return rnd(Decimal(exemptions) * EXEMPTION_AMOUNT_PER)

def find_bracket(annualized_gross):
    """Return (rate, base, floor) for the applicable bracket."""
    for floor, rate, base in reversed(FEDERAL_BRACKETS):
        if annualized_gross >= floor:
            return rate, base, floor
    # Fallback (should not happen)
    return Decimal('0'), Decimal('0'), Decimal('0')

def calculate_federal_tax(taxable_gross):
    """Return federal tax for the period."""
    annualized = rnd(taxable_gross * Decimal('26'))
    rate, base, floor = find_bracket(annualized)
    excess = rnd(annualized - floor)
    if excess < 0:
        excess = Decimal('0')
    annual_tax = rnd(base + rnd(excess * rate / Decimal('100')))
    return rnd(annual_tax / Decimal('26'))

def calculate_state_tax(taxable_gross, state_code):
    """Return state tax for the period."""
    rate = STATE_RATES.get(state_code, Decimal('0'))
    return rnd(taxable_gross * rate / Decimal('100'))

def calculate_fica_medicare(gross_pay, ytd_gross):
    """Return (fica_tax, medicare_tax, cap_reached_flag)."""
    cap_reached = False
    if ytd_gross >= FICA_WAGE_CAP:
        fica = Decimal('0')
        cap_reached = True
    else:
        fica = rnd(gross_pay * FICA_RATE)
    medicare = rnd(gross_pay * Decimal('0.0145'))
    if ytd_gross > MEDICARE_ADDL_THRESHOLD:
        medicare = rnd(medicare + rnd(gross_pay * MEDICARE_ADDL_RATE))
    return fica, medicare, cap_reached

def process_deductions(emp, gross_pay):
    """Return total deductions for the employee."""
    total = Decimal('0')
    for ded in emp['deductions'][:emp['deduction_count']]:
        if ded['type'] == 'F':
            total = rnd(total + ded['amount'])
        elif ded['type'] == 'P':
            total = rnd(total + rnd(gross_pay * ded['amount'] / Decimal('100')))
    return total

def print_batch_header():
    print('-' * 72)
    print('PAYROLL BATCH RUN')
    print('-' * 72)

def print_employee_detail(emp, gross, federal, state, fica, medicare, deductions, net):
    print('-' * 72)
    print(f"EMPLOYEE: {emp['employee_id']} {emp['first_name']} {emp['last_name']}")
    print(f"GROSS PAY:        {gross:.2f}")
    print(f"FEDERAL TAX:      {federal:.2f}")
    print(f"STATE TAX:        {state:.2f}")
    print(f"FICA TAX:         {fica:.2f}")
    print(f"MEDICARE TAX:     {medicare:.2f}")
    print(f"TOTAL DEDUCTIONS: {deductions:.2f}")
    print(f"NET PAY:          {net:.2f}")

def print_batch_summary(paid, skipped, total_gross, total_net, total_fed, total_state):
    print('-' * 72)
    print('BATCH SUMMARY')
    print(f"EMPLOYEES PAID:    {paid}")
    print(f"EMPLOYEES SKIPPED: {skipped}")
    print(f"TOTAL GROSS:       {total_gross:.2f}")
    print(f"TOTAL FEDERAL TAX: {total_fed:.2f}")
    print(f"TOTAL STATE TAX:   {total_state:.2f}")
    print(f"TOTAL NET:         {total_net:.2f}")
    print(MSG2_BATCH_COMPLETE)
    print('-' * 72)

def main():
    employees = load_employees()
    print_batch_header()

    batch_total_gross = Decimal('0')
    batch_total_net = Decimal('0')
    batch_total_fed = Decimal('0')
    batch_total_state = Decimal('0')
    batch_paid = 0
    batch_skipped = 0

    for emp in employees:
        if emp['status_code'] == 'T':
            print(MSG2_EMPLOYEE_TERMINATED)
            batch_skipped += 1
            continue
        elif emp['status_code'] == 'L':
            print(MSG2_EMPLOYEE_ON_LEAVE)
            batch_skipped += 1
            continue

        # Active employee processing
        gross = calculate_gross_pay(emp)
        exemption = calculate_exemption_amount(emp['exemptions'])
        taxable = rnd(gross - exemption)
        if taxable < 0:
            taxable = Decimal('0')

        federal_tax = calculate_federal_tax(taxable)
        state_tax = calculate_state_tax(taxable, emp['state_code'])
        fica_tax, medicare_tax, cap_reached = calculate_fica_medicare(gross, emp['ytd_gross'])
        if cap_reached:
            print(MSG2_FICA_CAP_REACHED)

        total_deductions = process_deductions(emp, gross)
        net_pay = rnd(gross - federal_tax - state_tax - fica_tax - medicare_tax - total_deductions)
        if net_pay < 0:
            print(MSG2_NEGATIVE_NET_PAY)
            net_pay = Decimal('0')

        print_employee_detail(emp, gross, federal_tax, state_tax, fica_tax, medicare_tax, total_deductions, net_pay)

        # Update YTD
        emp['ytd_gross'] = rnd(emp['ytd_gross'] + gross)
        emp['ytd_federal_tax'] = rnd(emp['ytd_federal_tax'] + federal_tax)
        emp['ytd_state_tax'] = rnd(emp['ytd_state_tax'] + state_tax)
        emp['ytd_fica'] = rnd(emp['ytd_fica'] + fica_tax)
        emp['ytd_net'] = rnd(emp['ytd_net'] + net_pay)

        # Update batch totals
        batch_total_gross = rnd(batch_total_gross + gross)
        batch_total_net = rnd(batch_total_net + net_pay)
        batch_total_fed = rnd(batch_total_fed + federal_tax)
        batch_total_state = rnd(batch_total_state + state_tax)
        batch_paid += 1

    print_batch_summary(batch_paid, batch_skipped, batch_total_gross, batch_total_net, batch_total_fed, batch_total_state)

if __name__ == '__main__':
    main()