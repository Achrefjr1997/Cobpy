from pydantic import BaseModel
from decimal import Decimal

MSG2_EMPLOYEE_TERMINATED: str = 'EMPLOYEE IS TERMINATED - SKIPPING'
MSG2_EMPLOYEE_ON_LEAVE: str = 'EMPLOYEE ON LEAVE - NO PAY PROCESSED'
MSG2_NEGATIVE_NET_PAY: str = 'WARNING - NEGATIVE NET PAY CALCULATED'
MSG2_FICA_CAP_REACHED: str = 'FICA WAGE CAP REACHED THIS PERIOD'
MSG2_INVOICE_PAST_DUE: str = 'INVOICE PAST DUE - LATE FEE APPLIED'
MSG2_CUSTOMER_ON_HOLD: str = 'CUSTOMER ON CREDIT HOLD'
MSG2_BATCH_COMPLETE: str = 'BATCH PROCESSING COMPLETE'

FILLER: str = '00000000010000000000'
FILLER: str = '00110000012000120000'
FILLER: str = '00440000018000220000'
FILLER: str = '00950000024000370000'
FILLER: str = '01820000032000550000'
FILLER: str = '02310000037000600000'
WS_FICA_RATE: Decimal = 0.0765
WS_FICA_WAGE_CAP: Decimal = 168600.00
WS_MEDICARE_ADDL_RATE: Decimal = 0.0090
WS_MEDICARE_ADDL_THRESHOLD: Decimal = 200000.00

class PaytableModel(BaseModel):
    """Generated from PAYTABLE."""

    ws_federal_bracket_redef: str  # PIC REDEFINES
    ws_bracket_entry: str  # PIC OCCURS
    ws_bracket_floor: Decimal  # PIC 9(7)V99
    ws_bracket_rate: Decimal  # PIC 9(2)V99
    ws_bracket_base_tax: Decimal  # PIC 9(5)V99

class EmpmastModel(BaseModel):
    """Generated from EMPMAST."""

    em_employee_id: str  # PIC X(08)
    em_first_name: str  # PIC X(20)
    em_last_name: str  # PIC X(30)
    em_ssn: str  # PIC X(11)
    em_hire_date: int  # PIC 9(8)
    em_department_code: str  # PIC X(04)
    em_job_class: str  # PIC X(02)
    em_pay_rate: Decimal  # PIC 9(5)V99
    em_annual_salary: Decimal  # PIC 9(9)V99
    em_filing_status: str  # PIC X(01)
    em_state_code: str  # PIC X(02)
    em_exemptions: int  # PIC 9(2)
    em_ytd_gross: Decimal  # PIC 9(9)V99
    em_ytd_federal_tax: Decimal  # PIC 9(9)V99
    em_ytd_state_tax: Decimal  # PIC 9(9)V99
    em_ytd_fica: Decimal  # PIC 9(9)V99
    em_ytd_net: Decimal  # PIC 9(9)V99
    em_status_code: str  # PIC X(01)
    em_deduction_count: int  # PIC 9(2)
    em_deduction_table: str  # PIC OCCURS
    ded_code: str  # PIC X(04)
    ded_description: str  # PIC X(20)
    ded_type: str  # PIC X(01)
    ded_amount: Decimal  # PIC 9(7)V99
    ded_ytd_total: Decimal  # PIC 9(9)V99
    em_dependent_count: int  # PIC 9(2)
    em_dependent_table: str  # PIC OCCURS
    dep_name: str  # PIC X(30)
    dep_relationship: str  # PIC X(01)
    dep_birth_date: int  # PIC 9(8)